#!/usr/bin/env python
# coding=utf-8

import os
import sys
from importlib import reload

import jieba
import warnings
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn import metrics


warnings.filterwarnings('ignore')


if sys.version.startswith('2.'):
    reload(sys)
    sys.setdefaultencoding('utf-8')


def load_file(file_path):
    with open(file_path) as f:
        lines = f.readlines()

    titles = []
    labels = []

    for line in lines:
        line = line.encode('unicode-escape').decode('unicode-escape')
        line = line.strip().rstrip('\n')

        _lines = line.split('---')
        if len(_lines) != 2:
            continue

        label, title = _lines
        words = jieba.cut(title)

        s = ' '.join(words)
        s = s.strip()

        titles.append(s)
        labels.append(label)


    return titles, labels


def load_data(_dir):
    file_list = os.listdir(_dir)

    titles_list = []
    labels_list = []

    for file_name in file_list:
        file_path = _dir + '/' + file_name

        titles, labels = load_file(file_path)

        titles_list += titles
        labels_list += labels

    return titles_list, labels_list


def load_stopwords(file_path):
    with open(file_path) as f:
        lines = f.readlines()

    words = []
    for line in lines:
        line = line.encode('unicode-escape').decode('unicode-escape')
        line = line.strip('\n')
        words.append(line)

    return words


if __name__ == '__main__':
    # 加载停用词
    stop_words = load_stopwords('stop_word/stopword.txt')

    # 加载训练数据
    train_datas, train_labels = load_data('train_data')

    # 加载测试数据
    test_datas, test_labels = load_data('test_data')

    # 计算单词权重（通过单词出现的次数，次数越多就表示越重要，把重要的单词挑出来作为特征）: 一般在拟合转换数据时，先用fit_transform处理训练集数据，再用transform处理测试集数据
    tf = TfidfVectorizer(stop_words = stop_words, max_df=0.5)
    train_features = tf.fit_transform(train_datas)
    test_features = tf.transform(test_datas)

    # 多项式贝叶斯分类器
    clf = MultinomialNB(alpha = 0.001).fit(train_features, train_labels)

    # 预测数据
    predicted_labels = clf.predict(test_features)

    # 计算准确率
    score = metrics.accuracy_score(test_labels, predicted_labels)
    print('metrics.accuracy_score: ', score)

    #test
    words = jieba.cut('东莞市场采购贸易联网信息平台参加部委首批联合验收')
    s = ' '.join(words)
    test_features = tf.transform([s])
    predicted_labels = clf.predict(test_features)
    print(predicted_labels[0])

    words = jieba.cut('留在中超了！踢进生死战决胜一球，武汉卓尔保级成功')
    s = ' '.join(words)
    test_features = tf.transform([s])
    predicted_labels = clf.predict(test_features)
    print(predicted_labels[0])

    words = jieba.cut('陈思诚全新系列电影《外太空的莫扎特》首曝海报 黄渤、荣梓杉演父子')
    s = ' '.join(words)
    test_features = tf.transform([s])
    predicted_labels = clf.predict(test_features)
    print(predicted_labels[0])

    words = jieba.cut('红薯的好处 常吃这种食物能够帮你减肥')
    s = ' '.join(words)
    test_features = tf.transform([s])
    predicted_labels = clf.predict(test_features)
    print(predicted_labels[0])